"""
This subpackage contains base classes that are not used directly by a user.
These classes are used as parent classes; they contain reusable code. 
"""

