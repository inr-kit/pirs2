"""
Convert string representation of a chemical formula to a tramat mixture definition.

For example:

    mdef = formula_to_mixture_definition('Al2O3')


"""

