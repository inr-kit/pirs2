"""
hli (Higl-level interfaces) docstrings.
"""


