from model import Bundle, Rod, Relation

# dimensions:
pp = 2. # pin pitch
r = 0.9 # pin radius
Np = 10 # number of pin rows and columns in the assembly

a = Bundle()
