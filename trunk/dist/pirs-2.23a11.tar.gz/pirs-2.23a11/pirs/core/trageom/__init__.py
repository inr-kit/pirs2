"""
Trageom docstrings.
"""

from .vector import Vector3, pi, pi2
